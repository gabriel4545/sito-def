/*
Mascon Dump for DWAMUploader
Date:    2002/01/23 18:30:19
*/

#----------------------------
# Table structure
#----------------------------
create table DWAMUploader (
   filenum int(11) not null auto_increment,
   filename varchar(50),
   filesize int(11) default '0',
   contenttype varchar(50),
   filedata longblob,
   primary key (filenum),
   index PRIMARY_KEY (filenum))
   type=MyISAM;