********************************************************************************
DWAM.NT	FILE UPLOADER for ASP and MySQL
********************************************************************************
*******	author : Guillaume de Lafontaine
*******	email : webmaster@dwam.net
*******	website : http://www.dwam.net
*******	version 1.0 - released 23 Jan 2002
********************************************************************************

Hi!
Thanks for your interest.
DWAMUploader is a modified version of the Pure ASP File Upload application
provided by ASP101 (www.asp101.com). It allows to upload files through ASP
(without requiring the use of a third-party component) and to store them
on disk or in a database. DWAMUploader is optimized for MySQL.
It is supposed to be very easy to install, use and modify if you wish.
Obviously, DWAMUploader is free...

REQUIREMENTS : To run this web app, here's what you need :
	- Web Server with ASP (IIS, PWS, ...)
	- ODBC with MDAC 2.5 or sup (on web server)
	- MyODBC driver for MySQL (installed on the web server)
	- MySQL Server

	Optional :
	- MySQL GUI client (Mascon, MySQLGUI, MySQLFront, ...)

	Notes on requirements :
	- Though there is nothing to setup in MyODBC (no DSN required),
	MyODBC must be installed and function properly on the web server.
	- An option is to use the provided Access database instead of MySQL.


INSTALLATION : Before you start, you have to :
	IIS:
	- create a new folder in your site, called DWAMUploader
	- unzip dwamuploader.zip in this folder
	- update config.inc with correct values for your MySQL server
	  and for optional parameters
	- apply correct permissions to the "uploads" folder and optionally
	  to the Access database depending on your security strategy.
	MySQL:
	- execute dwamuploader.sql to the 'test' database (if you change this,
	  don't forget to modify config.inc aswell.)
	- check user permissions on MySQL and the database as defined in config.inc

	- open your browser and type http://your_domain/dwamuploader/
	  (or whatever you named it)

********************************************************************************
If you want to help or if you have code improvements that you want to share,
contact me <web@dwam.com>. You're welcome!
********************************************************************************